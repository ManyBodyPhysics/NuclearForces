This IPython notebook eft.ipynb does not require any additional
programs.
