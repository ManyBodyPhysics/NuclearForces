This IPython notebook obemodels.ipynb does not require any additional
programs.
