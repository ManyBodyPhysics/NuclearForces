This IPython notebook phenomenologyforces.ipynb does not require any additional
programs.
